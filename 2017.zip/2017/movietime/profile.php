<?php
	$loginPage = true;
	include("include/config.php");

	if(!isLogin())
	{
		header("location:login.php");
		exit();
	}
	$id       = $_SESSION['userId'];
	$email		= $_SESSION['email'];
  $where_id = array('user_id'=>$id,'email'=>$email);
  $result   = getSelectTable('user' ,$where_id, $con);
  $row      = mysqli_fetch_array($result);

  $first_name   = $row['first_name'];
  $last_name    = $row['last_name'];
	$email		    = $row['email'];
	$username	    = $row['username'];
	$password_length= strlen(base64_decode($row['password']));
	/**Profile change start**/
	if(isset($_POST['profile_save']))
	{
		$email			= getValue($con,'email');
		$first_name	= getValue($con,'first_name');
		$last_name	= getValue($con,'last_name');
		$username		= getValue($con,'username');
		if($email != "" && $first_name!='' && $last_name!='' && $username!='')
		{
			if(is_valid_email($email))
			{
				$checkemail=mysqli_query($con,"SELECT * FROM `user` WHERE `email`='$email' AND `user_id` NOT IN ('$id')");
				$count=mysqli_num_rows($checkemail);
				if($count<=0)
				{
						$form_data=array(
							'username'		=> $username,
							'email'				=> $email,
							'first_name'	=> $first_name,
							'last_name'		=> $last_name
							);
							$user_where=array('user_id' => $id);
							$user_id=dbRowUpdate('user', $form_data,$user_where, $con);
							$_SESSION['email'] 	= $email;
							setMessage("Profile changed succesfully!","alert alert-success");
					}
					else
					{
						setMessage("This email is already registered!","alert alert-sucess");
					}

				}
				else
				{
					setMessage("This emai is not valid!","alert alert-sucess");
				}
			}
			else
			{
				setMessage("All fields are compulsory!","alert alert-danger");
			}
		}
		/**profile change process end**/
		/**change password process start**/
		/**Profile change start**/
		if(isset($_POST['change_password']))
		{
			$old_password				= getValue($con,'old_password');
			$password						= getValue($con,'password');
			$confirm_password		= getValue($con,'confirm_password');
			if($password != "" && $old_password!='' && $confirm_password!='')
			{
				if($password == $confirm_password)
				{
					$where_user = array('email' => $email, 'password' => base64_encode($old_password));
					$qry = getSelectTable('user', $where_user, $con) ;
					$countuser = mysqli_num_rows($qry);
					if($countuser > 0)
					{
						$form_data=array(
							'password'		=> base64_encode($password)
							);
							$user_where=array('user_id' => $id,'email' => $email, 'password' => base64_encode($old_password));
							$user_id=dbRowUpdate('user', $form_data,$user_where, $con);
							setMessage("Password changes succesfully!","alert alert-success");
					}
					else
					{
						setMessage("Old password is not correct!","alert alert-danger");
					}
				}
				else
				{
					setMessage("The two passwords do not match! ","alert alert-danger");
				}
			}
			else
			{
				setMessage("All password fields are compulsory! ","alert alert-danger");
			}
		}
		/**change password process end **/


?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::Create Event</title>
<link rel="stylesheet" href="<?php echo $path; ?>assets/css/bootstrap-datetimepicker.css">
<?php include("include/common-css.php"); ?>
</head>

<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
        	<div class="your-profile">
            	<div class="your-profile-head">
                	<div class="your-profile-img">
                    	<!--<img src="assets/images/profile.png" alt="profile" class="img-responsive">-->
                    </div>
                </div>
            </div>
            <div class="profile-content-block">
            	<div class="container">
                	<div class="create-event-inner">
                        <div class="event-inner">
                            <div class="create-event-block">
																<?php include 'include/message.php';?>
                                <div class="create-event-head">
                                    <div class="event-title">
                                        <h3>Your profile</h3>
                                    </div>
                                    <div class="event-right-btn">
                                        <a class="btn btn-danger" href="logout.php">Log out</a>
                                    </div>
                                   </div>
                                   <div class="profile-info">
																		 <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                   		<div class="profile-infor-head">
                                        	<p>Personal Detail</p>
                                        </div>
                                   		<div class="form-group">
                                        	<label>First Name</label>
                                            <input type="text" placeholder="Enter Your first Name" name="first_name" value="<?php echo $first_name; ?>">
                                        </div>
                                        <div class="form-group">
                                        	<label>Last Name</label>
                                            <input type="text" placeholder="Enter Your first Name" name="last_name" value="<?php echo $last_name; ?>">
                                        </div>
                                        <div class="form-group">
                                        	<label>Your Email</label>
                                            <input type="text" placeholder="Enter Your Email" name="email" value="<?php echo $email; ?>">
                                        </div>
																				<div class="form-group">
                                        	<label>User Name</label>
                                            <input type="text" placeholder="Enter Your First Name" name="username" value="<?php echo $username; ?>">
                                        </div>
																				<div class="profile-btn">
		                                         <div class="event-right-btn">
		                                             <button type="reset" class="btn btn-danger">Cancel</button>
		                                         </div>
		                                         <div class="event-right-btn">
		                                             <button type="submit" name="profile_save" class="btn btn-danger save-btn">save</button>
		                                         </div>
		                                     </div>
		                                 </form>
                                   </div>
                                   <div class="profile-info">
                                   		<div class="profile-infor-head">
                                        	<p>Privacy & security</p>
                                        </div>
																				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" data-parsley-validate>
																				<div class="change-password">
                                        	<div class="profile-infor-sub-head">
                                            	<span class="profile-infor-head-sub">change your password</span>
                                            </div>
                                        	<div class="form-group">
                                                <label>Enter Your Old Password</label>
                                                <input type="password" name="old_password" placeholder="Enter Your Old Password" data-parsley-length="[<?php echo $password_length; ?>, <?php echo $password_length; ?>]" data-parsley-required-message="Old Password is Required" data-parsley-length-message="You could change it to: Password which is not long enough." data-parsley-trigger="keyup" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Enter Your New Password</label>
                                                <input type="password" name="password" placeholder="Enter Your New Password" required data-parsley-required-message="New Password is Required" data-parsley-length="[6, 50]" id="password">
                                            </div>
                                            <div class="form-group">
                                                <label>Enter Your Conform Password</label>
                                                <input type="password" data-parsley-length="[6, 50]" name="confirm_password" placeholder="Enter Your Conform Password" data-parsley-equalto="#password" required data-parsley-required-message="Confirm Password is Required" data-parsley-equalto-message="Password is mismatch">
                                            </div>
                                        	</div>
																					<div class="profile-btn">
		                                         <div class="event-right-btn">
		                                             <button type="reset" class="btn btn-danger">Cancel</button>
		                                         </div>
		                                         <div class="event-right-btn">
		                                             <button type="submit" name="change_password" class="btn btn-danger save-btn">save</button>
		                                         </div>
		                                     </div>
		                                 </form>
                                   </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script src="<?php echo $path; ?>assets/js/moment.js"></script>
<script src="<?php echo $path; ?>assets/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
  	//$('#event_date').datepicker({});
		$('#event_date').datetimepicker({
      format: 'M/DD/YYYY HH:mm:ss', //
    });
    });
</script>
</body>
</html>
