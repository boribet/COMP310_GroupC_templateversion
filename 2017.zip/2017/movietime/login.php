<?php
$loginPage = true;
include("include/config.php");

if(isLogin())
{
	header("location:index.php");
	exit();
}
/** login process start**/
if(isset($_POST['login']))
{

	$email		= getValue($con,'email');
	$password	= getValue($con,'password');

	if($email != "" && $password != "")
	{
		if(is_valid_email($email))
		{
				$password = base64_encode($password);

				$where_user = array('email' => $email, 'password' => $password);
				$qry = getSelectTable('user', $where_user, $con) ;

				$countuser = mysqli_num_rows($qry);

				if( $countuser > 0)
				{
					$row = mysqli_fetch_array($qry);
					$user_id = $row['user_id'];
					$email = $row['email'];

					$_SESSION['userId']		= $user_id;
					$_SESSION['email'] = $email;

					header("location:index.php");
					exit();
				}
				else
				{
					setMessage("Invalid email or password!","alert alert-danger");
				}
		}
		else
		{
			setMessage("Invalid email adress!","alert alert-danger");
		}
	}
	else
	{
		setMessage("All fields are compulsory!","alert alert-danger");
	}
}
/** login process end**/
/** Register process start **/
if(isset($_POST['register']))
{
	$email			= getValue($con,'email');
	$first_name	= getValue($con,'first_name');
	$last_name	= getValue($con,'last_name');
	$username		= getValue($con,'username');
	$password		= getValue($con,'password');
	$confirm_password		= getValue($con,'confirm_password');
	$date=date("Y-m-d H:i:s");
	if($email != "" && $password != "" && $first_name!='' && $last_name!='' && $username!='')
	{
		if(is_valid_email($email))
		{
			$where=array('email'=>$email);
			$count= getCount('user', $where, $con);
			if($count<=0)
			{
				if($password == $confirm_password)
				{
					$form_data=array(
							'username'		=> $username,
							'password'		=> base64_encode($password),
							'email'				=> $email,
							'first_name'	=> $first_name,
							'last_name'		=> $last_name,
							'created_date'=> $date
						);
						$user_id=dbRowInsertWithLastId('user', $form_data, $con);
						$_SESSION['email'] 	= $email;
						$_SESSION['userId']	= $user_id;
						setMessage("User registered succesfully!","alert alert-success");
						header("location:index.php");
						exit();
				}
				else
				{
					setMessage("The passwords do not match!","alert alert-danger");
				}
			}
			else
			{
				setMessage("This email is already registered in the system!","alert alert-danger");
			}
		}
		else
		{
			setMessage("Invalid email!","alert alert-danger");
		}
	}
	else
	{
		setMessage("All fields are compulsory!","alert alert-danger");
	}
}
/** Register process end **/
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::Home</title>
</head>
<?php include("include/common-css.php"); ?>
<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
             <div class="login-page">
             	<div class="container">
                	<div class="login-page-inner">
                    	<div class="row">
                            <div class="col-sm-6 pull-right">

															<?php
															if(isset($_POST['login']))
															{
															include 'include/message.php';
															}
															?>
                            	<div class="login-block-main">
                                	<div class="login-block-content">
                                    	<div class="login-block-title">
                                      	<h3>Login</h3>
                                      </div>
                                  		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" name="loginform" data-parsley-validate>
                                      	<div class="form-group">
                                          	<input type="email" name="email" placeholder="Email" required  	data-parsley-length="[10, 100]" data-parsley-required-message="Email is required!">
                                          </div>
                                          <div class="form-group">
                                          	<input type="password" name="password" placeholder="password" required data-parsley-required-message="Username is required!">
                                          </div>
                                          <div class="form-group">
                                          	<div class="login-submit-btn">
                                                  <input class="btn btn-danger validate" name="login" type="submit" value="Login">
                                              </div>
                                          </div>
                                      </form>
                                    </div>
																		<?php
																		if(isset($_POST['register']))
																		{
																			include 'include/message.php';
																		}
																		?>
                                    <div class="login-block-content">
                                    	<div class="login-block-title">
                                        	<h3>Register</h3>
                                        </div>
                                    		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" name="signup_form"  class="signup_form" data-parsley-validate>
                                      		<div class="form-group">
                                          	<input type="email" name="email" placeholder="Email" required  	data-parsley-length="[10, 100]" data-parsley-required-message="Email is required!" >
                                              </div>
                                              <div class="form-group">
                                                  <input type="text" name="first_name" placeholder="first name" required data-parsley-required-message="Firstname is required!" data-parsley-type="alphanum">
                                              </div>
                                              <div class="form-group">
                                                  <input type="text" name="last_name" placeholder="last name" required data-parsley-required-message="Lastname is required!" data-parsley-type="alphanum">
                                              </div>
                                              <div class="form-group">
                                                  <input type="text" name="username" placeholder="user name" required data-parsley-required-message="Username is required!" data-parsley-type="alphanum">
                                              </div>
                                              <div class="form-group">
                                                  <input type="password" name="password" id="password" placeholder="password" data-parsley-length="[6, 50]" data-parsley-required-message="Password is required!">
                                              </div>
																							<div class="form-group">
                                                  <input type="password" name="confirm_password" placeholder="Confirm Password" data-parsley-length="[6, 50]" data-parsley-equalto="#password" data-parsley-required-message="Password confirmation is required!" data-parsley-equalto-message="Password is mismatch">
                                              </div>
                                              <div class="form-group">
                                                  <div class="login-submit-btn">
                                                      <input class="btn btn-danger validate" name="register" id="register_btn" type="submit" value="Register">
                                                  </div>
                                              </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 pull-right">
                            	<div class="login-page-info">
                                	<h4>Lorem Ipsum is simply dummy text.</h4>
                                	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters</p>
                                    <h4>Lorem Ipsum is simply dummy text.</h4>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters</p>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <h4>Lorem Ipsum is simply dummy text.</h4>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters</p>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <h4>Lorem Ipsum is simply dummy text.</h4>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
             </div>
        </div>
    </section>
  	<?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script>

</script>
</body>
</html>
