<?php
	$loginPage = true;
	include("include/config.php");
	if(!isLogin())
	{
		//header("location:index.php");
		//exit();
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::browse Event</title>
<?php include("include/common-css.php"); ?>
<link href="<?php echo $path; ?>assets/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">

</head>

<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
             <div class="create-event">
             	<div class="container">
                	<div class="create-event-main">
                    	<div class="event-inner browse-event-inner">
                			<div class="create-event-head">
                    		<div class="event-title">
                                <h3>browse events</h3>
                            </div>
                        </div>
                    		<div class="browse-event-block">
                        	<form id="filter_form">
                            	<div class="row">
                                	<div class="col-md-3">
                                    	<div class="form-group">
                                        	<label>Select genre:</label>
                                            <div class="form-group-inner">
                                            	<select id="genre">
                                                	<option value="">All</option>
                                                	<?php
																										$getallcategory = get_all_data('category', $con);
																										while($all_category=mysqli_fetch_array($getallcategory,MYSQLI_BOTH))
																										{
																										?>
																											<option value="<?php echo $all_category['category']; ?>"><?php echo $all_category['category']; ?></option>
												                       								 <?php
																										  }
																										?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                    	<div class="form-group">
                                        	<label>Start date:</label>
                                        	<div class="form-group-inner">
                                        		<div class="input-group date">
                                                <input type="text" placeholder="Start Date" id="event_date">
                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
																		<div class="col-md-2">
                                    	<div class="form-group">
                                        	<label>End date:</label>
                                        	<div class="form-group-inner">
                                        		<div class="input-group date">
                                                <input type="text" placeholder="End Date" id="end_date">
                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                    	<div class="form-group">
                                        	<label>Select loaction:</label>
                                            <div class="form-group-inner">
                                            	<select id="location_id">
                                                	<option value="">Select Location</option>
																									<?php
                                                    $getalllocation = get_all_data('location', $con);
                                                    while($all_location=mysqli_fetch_array($getalllocation,MYSQLI_BOTH))
                                                    {
                                                  ?>
                                                    <option value="<?php echo $all_location['location_name']; ?>"><?php echo $all_location['location_name']; ?></option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                    	<div class="form-group">
                                        	<label>Search Events:</label>
                                            <input type="text" id="event_search" placeholder="Search...">
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                        <div class="form-group">
                                            <button type="button" class="btn btn-block btn-danger" onClick="window.reset_filter_form();">Reset</button>
                                        </div>
                                    </div>
																	</div>
                            </form>
                        </div>
                            <div class="event-list">
                                <table id="browse_event" class="table" cellspacing="0" width="100%">
                                    <thead class="hidden">
                                        <tr>
                                            <th>Event Name</th>
                                            <th>Film</th>
                                            <th>Date</th>
                                            <th>Event Length</th>
                                            <th>Capacity</th>
                                            <th>Location</th>
                                            <th>Genre</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            //$getall_event = get_all_data('event', $con);
																				$getall_event=mysqli_query($con,"SELECT * FROM `event` WHERE DATE(`event_time`) >= CURDATE() ORDER BY 'event_time'");
																				 while($all_event = mysqli_fetch_array($getall_event,MYSQLI_BOTH))
																				 {
																				  $reservation_where=array('event_id' => $all_event['event_id']);
																				  $booksit_count = getCount('reservation',$reservation_where, $con);
																				  $bookbutton=FALSE;
																				  if($booksit_count<$all_event['event_capacity'])
																				  {
																				   $bookbutton=TRUE;
																				  }

                                        ?>
                                        <tr class="event-list-left">
                                            <td class="event-title-content">
												<div class="event-title">
                                                    <h5><?php echo $all_event['event_name']; ?></h5>
                                                </div>
                                             </td>
                                            <td>
                                                 <?php
                                                    $film_where=array('film_id' => $all_event['film_id']);
                                                    $getallfilm = getSelectTable('film',$film_where, $con);
                                                    $all_film = mysqli_fetch_array($getallfilm,MYSQLI_BOTH);
                                                ?>
                                                <p>Film</p>
												<span><?php echo $all_film['title']; ?></span>
                                            </td>
                                            <td>
                                            	<p>Event Date</p>
												<span>
                                                 	<?php echo date('Y-m-d', strtotime($all_event['event_time'])); ?>
                                                 </span>
                                             </td>
                                            <td>
                                            	<p>Length</p>
												<span><?php echo $all_event['event_length']; ?></span>
                                            </td>
                                            <td>
                                            	<p>Capacity</p>
												<span><?php echo $all_event['event_capacity']; ?></span>
                                            </td>
                                            <td valign="middle">
                                                <?php
                                                    $location_where=array('location_id' => $all_event['location_id']);
                                                    $getalllocation = getSelectTable('location',$location_where, $con);
                                                    $all_location=mysqli_fetch_array($getalllocation,MYSQLI_BOTH);
                                                ?>
                                                <p>Location</p>
                                                <span><?php echo $all_location['location_name']; ?> </span>
                                           </td>
                                           <td>
                                           		 <?php
                                                    $film_where=array('film_id' => $all_event['film_id']);

                                                    $getallfilm = getSelectTable('film',$film_where, $con);
                                                    $all_film = mysqli_fetch_array($getallfilm,MYSQLI_BOTH);
													$cat_where=array('category_id' => $all_film['category_id']);
													$getallcategory = getSelectTable('category',$cat_where, $con);
													$all_category=mysqli_fetch_array($getallcategory,MYSQLI_BOTH);
                                                ?>
                                                <p>Genre</p>
                                           		<span><?php echo $all_category['category']; ?></span>
                                           </td>
                                           <td align="center" valign="middle" width="100px;" class="action-btn">
                                                <div class="event-right-btn">
                                                	<div class="action-btn-inner">
                                                    	<?php
																												  if($bookbutton)
																												  {
																												  ?>
																												   <a class="btn btn-danger" href="<?php echo $path.'book_event.php?id='.$all_event['event_id']; ?>">Book</a>
																												   <?php
																												  }
																												  else
																												  {
																												  ?>
																												   <a class="btn btn-danger sold-out-btn" href="#">SOLD OUT</a>
																												  <?php
																												  }
																												 ?>
                                                    </div>
                                                </div>
                                           </td>
                                        </tr>
                                         <?php
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
             </div>
        </div>
    </section>
    <?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script src="<?php echo $path; ?>assets/js/bootstrap-datepicker.min.js"	 type="text/javascript"></script>
<script src="<?php echo $path; ?>assets/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="<?php echo $path; ?>assets/js/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript">
	 $.fn.dataTable.ext.search.push(

		function (settings, data, dataIndex) {
			var min = $('#event_date').datepicker("getDate");
			var max = $('#end_date').datepicker("getDate");
      //var startDate = new Date(data[4]);
			var date = data[2];
			date = date.toString().replace("Event Date", '').split("-");
			var startDate = new Date(date[0]+ "-" +  date[1] +"-" + date[2]);
      if (min == null && max == null) { return true; }
      if (min == null && startDate <= max) { return true;}
      if(max == null && startDate >= min) {return true;}
      if (startDate <= max && startDate >= min) { return true; }
      return false;
    },

		/*function (settings, data, dataIndex) {
			var max = $('#event_date').datepicker("getDate");
			var date = data[2];
			date = date.toString().replace("Event Date", '').split("-");
			var startDate = new Date(date[0]+ "-" +  date[1] +"-" + date[2]);
			if (max == null) { return true; }
			if (startDate >= max) { return true; }
			return false;
		},*/
		function(settings, data, dataIndex){
			var genre = $('#genre').val();
			var genre_col = data[6].replace('Genre','');
				genre_col = $.trim(genre_col);

				if (genre == null || genre == "") { return true; }
				if (genre == genre_col) { return true; }

			return false;
		},
		function(settings, data, dataIndex){
			var location_id = $('#location_id').val();
			var location_col = data[5].replace('Location','');
				location_col = $.trim(location_col);

				if (location_id == null || location_id == "") { return true; }
				if (location_id == location_col) { return true; }

			return false;
		}

	);
	var table;
	$(document).ready(function() {
		$('#event_date').datepicker({
			format: 'yyyy-mm-dd',
			onSelect: function () { table.draw(); },
			changeMonth: true,
			changeYear: true,
			}).change(function () {
        table.draw();
    });
		$('#end_date').datepicker({
			format: 'yyyy-mm-dd',
			onSelect: function () { table.draw(); },
			changeMonth: true,
			changeYear: true,
			}).change(function () {
          table.draw();
      });

		table = $('#browse_event').DataTable({
			bLengthChange : false,
			pageLength : 5
		});

		$('#genre, #location_id').on('change keyup',function(){
			table.draw();
		});
		$('#event_search').on( 'keyup click', function () {
		   table.search(
			   $('#event_search').val()
		   ).draw();
		});

		window.reset_filter_form = function(){
			$('#genre, #location_id').prop('selectedIndex',0);
			$('#event_date').val("").datepicker("update");
			$('#end_date').val("").datepicker("update");
			$('#event_search').val('');
			table.search('').draw();
		}

	  });
</script>
</body>
</html>
