<?php
	require_once('include/config.php');
	require_once('include/database_function.php');

	$id 				= $_SESSION['userId'];
	$userrole 	= $_SESSION['userRole'];

	unset($_SESSION['userId']);
	unset($_SESSION['userRole']);
	setMessage("You have successfully logged out from the system!","alert alert-success");
	unset($_SESSION['message']);
	unset($_SESSION['message_type']);
	header("location:index.php");
	exit();
?>
