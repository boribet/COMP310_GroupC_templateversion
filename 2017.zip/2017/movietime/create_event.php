<?php
	$loginPage = true;
	include("include/config.php");
	if(!isLogin())
	{
		header("location:login.php");
		exit();
	}
	/** Register process start **/
	if(isset($_POST['event_create']))
	{
		$event_name					= getValue($con,'event_name');
		$event_time					= getValue($con,'event_time');
		$film_id						= getValue($con,'film_id');
		$location_id				= getValue($con,'location_id');
		$event_description	= getValue($con,'event_description');
		$type_id						= getValue($con,'type_id');
		$event_length				= getValue($con,'event_length');
		$event_capacity			= getValue($con,'event_capacity');
		$price							= getValue($con,'price');
		$date								= date("Y-m-d H:i:s");
		if($event_name != "" && $event_time != "" && $film_id!='' && $location_id!='' && $event_description!='' && $type_id!='' && $event_length!='')
		{
			$user_id=$_SESSION['userId'];
			$form_data=array(
					'event_name'		=> $event_name,
					'event_time'		=> $event_time,
					'film_id'				=> $film_id,
					'location_id'		=> $location_id,
					'event_description'=>$event_description,
					'type_id'				=> $type_id,
					'event_length'	=> $event_length,
					'event_capacity'=> $event_capacity,
					'price'					=> $price,
					'hostuser_id'		=> $user_id,
					'created_date'	=> $date
			);
				$user_id=dbRowInsertWithLastId('event', $form_data, $con);

				setMessage("Event succesfully created! ","alert alert-success");
				header("location:event_hosted.php");
				exit();

		}
		else
		{
			setMessage("All fields are compulsory! ","alert alert-danger");
		}
	}
	/** Register process end **/
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::Create Event</title>
<link rel="stylesheet" href="<?php echo $path; ?>assets/css/bootstrap-datetimepicker.css">
<?php include("include/common-css.php"); ?>
</head>

<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
             <div class="create-event">
             	<div class="container">
                	<div class="create-event-main">
                		<div class="create-event-inner">
                        	<div class="event-inner">
                    			<div class="create-event-block">
													<?php include 'include/message.php';?>
                        	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" name="eventform" data-parsley-validate>
                            	<div class="create-event-head">
	                                <div class="event-title">
	                                    <h3>Creat a new event</h3>
	                                </div>
	                                <div class="event-right-btn">
	                                    <button type="submit" name="event_create" class="btn btn-danger validate" >Create event</button>
	                                </div>
		                        		</div>
                                <div class="create-event-form">
                            		<div class="row">
                                	<div class="col-sm-8">
                                    	<div class="form-group">
                                          <input type="text" placeholder="Event Name" name="event_name" required data-parsley-required-message="Event Name is Required">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                    	<div class="form-group">
																				<div class="col-xs-12 input-group">
																						<input type="text" id='event_date' name="event_time" class="form-control" placeholder="Select event date">
																						<span class="input-group-addon">
																							<span class="glyphicon glyphicon-calendar"></span>
																						</span>
																					</div>
                                        </div>
                                    </div>
																		<div class="col-sm-12">
                                    	<div class="form-group">
                                            <select name="film_id" required data-parsley-required-message="Film selection is required!">
																							<option value="">SELECT FILM</option>
																							<?php
																									$getallfilm_qry = get_all_data('film', $con);
																									while($all_film = mysqli_fetch_array($getallfilm_qry,MYSQLI_BOTH))
																									{
																										?>
																										<option value="<?php echo $all_film['film_id']; ?>"><?php echo $all_film['title']; ?></option>
																										<?php
																									}
																								?>
                                            </select>
                                        </div>
                                    </div>
																		<div class="col-sm-12">
                                    	<div class="form-group">
                                            <select name="location_id" required data-parsley-required-message="Location name is required! ">
																							<option value="">SELECT LOCATION</option>
																							<?php
																									$getalllocation_qry = get_all_data('location', $con);
																								while($all_location=mysqli_fetch_array($getalllocation_qry,MYSQLI_BOTH))
																									{
																										?>
																										<option value="<?php echo $all_location['location_id']; ?>"><?php echo $all_location['location_name']; ?></option>
																										<?php
																									}
																								?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                    	<div class="form-group">
                                            <textarea placeholder="Event Description" name="event_description" required data-parsley-required-message="Event description is required!"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                    	<div class="form-group">
																				<select name="type_id" required data-parsley-required-message="Event type is required!">
																					<option value="">EVENT TYPE</option>
																					<?php
																							$getalltype_qry = get_all_data('type', $con);
																							while($all_type = mysqli_fetch_array($getalltype_qry,MYSQLI_BOTH))
																							{
																								?>
																								<option value="<?php echo $all_type['type_id']; ?>"><?php echo $all_type['name']; ?></option>
																								<?php
																							}
																						?>
																				</select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                    	<div class="form-group">
                                            <input type="text" id="event_length" name="event_length" placeholder="Time Of Duaration">
                                        </div>
                                    </div>
																		<div class="col-sm-6">
                                    	<div class="form-group">
                                        <input type="text" data-parsley-type="digits" placeholder="Enter Capacity of people" name="event_capacity" required data-parsley-required-message=" Capacity of people is required!">
                                      </div>
	                                 </div>
																	 <div class="col-sm-6">
																		 <div class="form-group">
																			 <input type="text" data-parsley-type="number" placeholder="Enter price of event" name="price" required data-parsley-required-message="Price of event is required!">
																		 </div>
																	</div>
                            	</div>
                                </div>
                            </form>
                        </div>
                        	</div>
                    	</div>
                    </div>
                </div>
             </div>
        </div>
    </section>
    <?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script src="<?php echo $path; ?>assets/js/moment.js"></script>
<script src="<?php echo $path; ?>assets/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
  	//$('#event_date').datepicker({});
		$('#event_date').datetimepicker({
      format: 'YYYY/MM/DD HH:mm:ss', //
			 minDate:new Date()
    });
		$('#event_length').datetimepicker({
      format: 'HH:mm:ss', //
    });
    });
</script>
</body>
</html>
