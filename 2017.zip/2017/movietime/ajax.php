<?php
	include 'include/config.php';
	$data_type=getValue($con,'data_type');

	switch($data_type)
	{
		//email check
		case 'check_email':
			$table_name=getValue($con,'table_name');
			$email=getValue($con,'email');
			$where=array('email'=>$email);
			$count= getCount($table_name, $where, $con);
			if($count<=0)
			{
				echo "TRUE";
			}
			else
			{
				echo "FALSE";
			}
		break;
		case 'getsingle_eventdata':
				$event_id				= getValue($con,'event_id');
				$event_where		= array('event_id' => $event_id);
				//$getall_event 	= getSelectTable('event',$event_where, $con);
				$getall_event=mysqli_query($con,"SELECT * FROM `event` WHERE event_id=$event_id AND DATE(`event_time`) >= CURDATE() ORDER BY 'event_time'");
				if(mysqli_num_rows($getall_event))
				{
					$all_event 			= mysqli_fetch_array($getall_event,MYSQLI_BOTH);
					$event_date			= $all_event['event_time'];
					$event_length		= $all_event['event_length'];
					$price					= $all_event['price'];
					$event_capacity	= $all_event['event_capacity'];
					$user_where			= array('user_id' => $all_event['hostuser_id']);
					$getalluser 		= getSelectTable('user',$user_where, $con);
					$all_user 			= mysqli_fetch_array($getalluser,MYSQLI_BOTH);
					$host_user			= $all_user['username'];
					$film_where			= array('film_id' => $all_event['film_id']);
					$getallfilm 		= getSelectTable('film',$film_where, $con);
					$all_film 			= mysqli_fetch_array($getallfilm,MYSQLI_BOTH);
					$film_name			= $all_film['title'];
					$imdb_rating		= $all_film['imdb_rating'];
					$location_where = array('location_id' => $all_event['location_id']);
					$getalllocation = getSelectTable('location',$location_where, $con);
					$all_location		= mysqli_fetch_array($getalllocation,MYSQLI_BOTH);
					$location				= $all_location['location_name'];
					$reservation_where=array('event_id' => $all_event['event_id']);
					$booksit_count = getCount('reservation',$reservation_where, $con);
					$bookbutton=FALSE;
					if($booksit_count<$all_event['event_capacity'])
					{
						$bookbutton=TRUE;
					}
					echo '<div class="event-list">
							<div class="event-list-left">
									<div class="event-title">
												<h5>events Info</h5>
										</div>
								<div class="event-list-table">
									<ul>
											<li>
													<p>Host User Name</p>
														<span>'.$host_user.'</span>
												</li>
											<li>
													<p>film</p>
														<span>'.$film_name.'</span>
												</li>
												<li>
													<p>IMDB Rating</p>
														<span>'.$imdb_rating.'</span>
												</li>
												<li>
													<p>date</p>
														<span>'.$event_date.'</span>
												</li>
												<li>
													<p>Event Duration</p>
														<span>'.$event_length.'</span>
												</li>
												<li>
													<p>Capacity</p>
													<span>'.$event_capacity.'</span>
												</li>
												<li>
													<p>loaction</p>
														<span>'.$location.'</span>
												</li>
												<li>
													<p>Price</p>
														<span><b>$'.$price.'</b></span>
												</li>
										</ul>
								 </div>
								</div>
								<div class="event-right-btn">';
										if($bookbutton)
											{
												echo '<button type="submit" class="btn btn-danger" name="book_event" >Book</button>';
											}
											else
											{
											echo '<button type="button" class="btn btn-danger">SOLD OUT</button>';
											}
								echo '</div>
						</div>';
					}
					else{
						echo '<p class="alert alert-danger">This is not a valid event for registration</p>';
					}
					break;
					case 'book_event':
					$user_id	= $_SESSION['userId'];
					$event_id	= getValue($con,'event_id');
					$reservation_where=array('event_id' => $event_id, 'user_id'=>$user_id);
					$booksit_count = getCount('reservation',$reservation_where, $con);
					if ($booksit_count>=1) {
						echo '<p class="alert alert-danger">You have already booked this event! </p>';
					}
					else {
						$date			= date("Y-m-d H:i:s");
						$form_data=array(
								'user_id'				=> $user_id,
								'event_id'			=> $event_id,
								'purchase_date'	=> $date
						);
							$user_id=dbRowInsertWithLastId('reservation', $form_data, $con);
							setMessage("Event booked successfully! ","alert alert-success");
							header("location:my_reservation.php");
							exit();
					}
					break;
					case 'getsales_info':
						$event_id				= getValue($con,'event_id');
						$event_where		= array('event_id' => $event_id);
						$getall_event 	= getSelectTable('event',$event_where, $con);
						$all_event 			= mysqli_fetch_array($getall_event,MYSQLI_BOTH);
						$event_name			= $all_event['event_name'];
						$event_length		= $all_event['event_length'];
						$event_capacity	= $all_event['event_capacity'];

						$film_where			= array('film_id' => $all_event['film_id']);
						$getallfilm 		= getSelectTable('film',$film_where, $con);
						$all_film 			= mysqli_fetch_array($getallfilm,MYSQLI_BOTH);
						$film_name			= $all_film['title'];

						$reservation_where=array('event_id' => $event_id);
						$booksit_count = getCount('reservation',$reservation_where, $con);
						$available_sit = $event_capacity-$booksit_count;
						echo '<div class="event-post-main event-reservtion sales-info">
									<div class="post-event">
										<div class="event-title-head sales-info-title">
												<p>ticket sales</p>
										</div>
										<div class="event-list">
												<div class="event-list-left">
														<div class="event-title">
																<h5>'.$event_name.'</h5>
														</div>
														<div class="event-list-table">
																<ul>
																	<li>
																			 <p>film</p>
																			 <span>'.$film_name.'</span>
																		</li>
																		<li>
																				<p>Total Ticket</p>
																				<span>'.$event_capacity.'</span>
																		</li>
																		<li>
																				<p>Book Ticket</p>
																				<span>'.$booksit_count.'</span>
																		</li>
																		<li>
																				<p>Available Ticket</p>
																				<span>'.$available_sit.'</span>
																		</li>
																</ul>
														 </div>
												 </div>
										</div>
							</div>
								<div class="post-event">
										<div class="event-title-head participate-info">
												<p>participate</p>
										</div>
								<div class="event-list">
												<div class="event-list-left">
														<div class="event-title">
																<h5>'.$event_name.'</h5>
														</div>
														<div class="event-list-table">
																<ul>
																	<li>
																			 <p>Name</p>
																			 <span>Email</span>
																		</li>';
																		$reservation_where=array('event_id' => $event_id);
																		$getall_reservation = getSelectTable('reservation',$reservation_where, $con);
																		while($all_reservation = mysqli_fetch_array($getall_reservation,MYSQLI_BOTH))
																		{
																		$user_where			= array('user_id' => $all_reservation['user_id']);
																		$getalluser 		= getSelectTable('user',$user_where, $con);
																		$all_user 			= mysqli_fetch_array($getalluser,MYSQLI_BOTH);
																		$email					= $all_user['email'];
																		$first_name			=	$all_user['first_name'];
																		$last_name			=	$all_user['last_name'];
																		echo '<li>
																			 <p>'.$first_name.' '.$last_name.'</p>
																			 <span>'.$email.'</span>
																		</li>';
																	}
																	echo'
																</ul>
														 </div>
												 </div>
										</div>
							</div>
						</div>';
					break;

					//default
					default:
						echo "This type of information is not available.";
					break;
	}

?>
