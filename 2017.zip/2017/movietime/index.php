<?php
	$loginPage = true;
	include("include/config.php");
	$setLimit = 3;
	if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
	$start_from = ($page-1) * $setLimit;
	$pageLimit = ($page * $setLimit) - $setLimit;
	$user_id = $_SESSION['userId'];
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::Home</title>
<?php include("include/common-css.php"); ?>
<link href="<?php echo $path; ?>assets/css/slick.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
            <!-- <div class="event-slider-main">
             	<div class="event-slider-inner">
                	<div class="event-slider">
                    		<div class="event-slider-img">
                        	<div class="event-slider-content">
                        		<img src="assets/images/slide1.png" alt="slide" class="img-responsive">
                            	<div class="event-slide-info">
                            	<h2>Lorem Inspector Dummy Text</h2>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                            </div>
                            </div>
                        </div>
                        <div class="event-slider-img">
                        	<div class="event-slider-content">
                        		<img src="assets/images/slide2.png" alt="slide" class="img-responsive">
                            	<div class="event-slide-info">
                            	<h2>Lorem Inspector Dummy Text</h2>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                            </div>
                            </div>
                        </div>
                        <div class="event-slider-img">
                        	<div class="event-slider-content">
                        		<img src="assets/images/slide1.png" alt="slide" class="img-responsive">
                            	<div class="event-slide-info">
                            	<h2>Lorem Inspector Dummy Text</h2>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
             </div>-->
             <div class="event-detail">
             	<div class="container">
                	<div class="our-event">
                	<div class="page-title">
                    	<h1>Recent Event</h1>
                    </div>
                	<div class="event-detail-inner">
                    	<div class="row">
												<?php
												$getall_event=mysqli_query($con,"SELECT * FROM `event` WHERE DATE(`event_time`) >= CURDATE() ORDER BY 'event_time' LIMIT $start_from, $setLimit ");
												 while($all_event = mysqli_fetch_array($getall_event,MYSQLI_BOTH))
												 {
												?>
                        	<div class="col-sm-4">
                            	<div class="event-detail-body">
                    					<div class="event-detail-img">
                        				<img src="assets/images/event1.jpg" alt="event" class="img-responsive">
                       				</div>
                        			<div class="event-detail-content">
                              	<h4><?php echo $all_event['event_name']; ?></h4>
                                  <p><?php echo $all_event['event_description']; ?></p>
                              </div>
                        		</div>
                        	</div>
												<?php
													}
												?>
                        </div>
                    </div>
                    </div>
										<div class="pagination_wraper">
				 						 <?php
											 $query = "SELECT COUNT(*) as totalCount FROM event WHERE DATE(`event_time`) >= CURDATE()";
											 $rec = mysqli_fetch_array(mysqli_query($con,$query));
											 $total = $rec['totalCount'];
				 						 		echo displayPaginationindex($setLimit,$page,'event',$total,$con);
				 							 ?>
				 						 </div>
                </div>
             </div>
        </div>
    </section>
    <?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script src="<?php echo $path; ?>assets/js/slick.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.event-slider').slick({
			infinite: true,
			dots: false,
			arrows: true,
			speed: 1000,
		});
    });
</script>
</body>
</html>
