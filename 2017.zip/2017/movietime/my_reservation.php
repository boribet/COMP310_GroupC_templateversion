<?php
	$loginPage = true;
	include("include/config.php");
	if(!isLogin())
	{
		header("location:login.php");
		exit();
	}
	$user_id = $_SESSION['userId'];
	$setLimit = 3;
	if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
	$start_from = ($page-1) * $setLimit;

	if(isset($_GET["res_page"])){ $res_page  = $_GET["res_page"]; } else { $res_page=1; };
	$start_respage=($res_page-1) * $setLimit;;
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::Event reservation</title>
<?php include("include/common-css.php"); ?>
<link href="<?php echo $path; ?>assets/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">

</head>

<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
             <div class="create-event">
             	<div class="container">
                	<div class="create-event-main">
                    	<div class="event-inner">
											<?php include 'include/message.php';?>
                			<div class="create-event-head">
													<div class="event-title">
                            <h3>your reservation</h3>
                          </div>
                        </div>
                    		<div class="browse-event-block event-reservtion">
                          <form>
														<?php
														$getall_event=mysqli_query($con,"SELECT * FROM reservation r
														INNER JOIN event e ON r.event_id = e.event_id
														WHERE r.user_id =$user_id AND DATE(`event_time`)> CURDATE() LIMIT $start_respage, $setLimit");
														$total_row=mysqli_num_rows($getall_event);
														if(mysqli_num_rows($getall_event)>0)
														{
															while($all_event = mysqli_fetch_array($getall_event,MYSQLI_BOTH))
															{
														?>
                            <div class="event-list">
                              <div class="event-list-left">
                                	<div class="event-title">
                                      <h5><?php echo $all_event['event_name']; ?></h5>
                                  </div>
                                  <div class="event-list-table">
                                      <ul>
                                      	<li>
                                           <p>Film</p>
																					 <?php
	 																						$film_where=array('film_id' => $all_event['film_id']);
	 																						$getallfilm = getSelectTable('film',$film_where, $con);
	 																						$all_film = mysqli_fetch_array($getallfilm,MYSQLI_BOTH);
	 																					?>
	 																				<span><?php echo $all_film['title']; ?></span>
                                        </li>
                                        <li>
                                            <p>Event Date</p>
                                            <span><?php echo $all_event['event_time']; ?></span>
                                        </li>
                                        <li>
                                            <p>Loaction</p>
																						<?php
																								$location_where=array('location_id' => $all_event['location_id']);
																								$getalllocation = getSelectTable('location',$location_where, $con);
																								$all_location=mysqli_fetch_array($getalllocation,MYSQLI_BOTH);
																						?>
																						<span><?php echo $all_location['location_name']; ?> </span>
                                        </li>
																				<li>
																						<p>Duratiom</p>
																						<span><?php echo $all_event['event_length']; ?></span>
																				</li>
																				<li>
																					<p>Capacity</p>
																					<span><?php echo $all_event['event_capacity']; ?></span>
																				</li>
                                      </ul>
                                   </div>
                                  </div>
                              	</div>
																<?php
																	}
																}
																else {
																	?>
																	<h5 class="alert alert-danger">Sorry! No event Found</h5>
																<?php
																}
																?>
                              </form>
															<div class="pagination_wraper">
								 						 <?php
														 $sql = "SELECT COUNT(e.event_id) FROM reservation r INNER JOIN event e ON r.event_id = e.event_id WHERE r.user_id =$user_id AND DATE(`event_time`) > CURDATE()";
								 							 $rs_result = mysqli_query($con,$sql);
								 							 $row =mysqli_fetch_row($rs_result);
								 							 $total_records = $row[0];
															 $total_pages = ceil($total_records / $setLimit);
								 							 $pagLink = "<div class='pagination'>";
								 							 for ($i=1; $i<=$total_pages; $i++) {
								 								 $active='';
								 								 if($res_page==$i)
								 								 {
								 									 $active="active";
								 								 }
								 								 $pagLink .= "<a class='$active' href=".htmlspecialchars($_SERVER["PHP_SELF"])."?res_page=".$i."&page=".$page.">".$i."</a>";
								 							 };
															 if($total_records>1)
															 {
																 echo $pagLink . "</div>";
															 }
								 							 ?>
								 						 </div>
                        		</div>
                            <div class="event-post-main">
                            	<div class="post-event">
                            	<div class="event-title-head">
                                	<p>Past event</p>
                                </div>
																<?php
																$getall_data=mysqli_query($con,"SELECT * FROM reservation r
																INNER JOIN event e ON r.event_id = e.event_id
																WHERE r.user_id =$user_id AND DATE(`event_time`)<=CURDATE() LIMIT $start_from, $setLimit");
															$total_row=mysqli_num_rows($getall_data);
															if($total_row>=1)
															{
																 while($all_event = mysqli_fetch_array($getall_data,MYSQLI_BOTH))
																 {
																	 ?>
	                            			<div class="event-list">
	                                    <div class="event-list-left">
	                                    	<div class="event-title">
	                                          <h5><?php echo $all_event['event_name']; ?></h5>
	                                        </div>
	                                        <div class="event-list-table">
	                                            <ul>
																								<li>
				                                           <p>Film</p>
																									 <?php
					 																						$film_where=array('film_id' => $all_event['film_id']);
					 																						$getallfilm = getSelectTable('film',$film_where, $con);
					 																						$all_film = mysqli_fetch_array($getallfilm,MYSQLI_BOTH);
					 																					?>
					 																				<span><?php echo $all_film['title']; ?></span>
				                                        </li>
				                                        <li>
				                                            <p>Event Date</p>
				                                            <span><?php echo $all_event['event_time']; ?></span>
				                                        </li>
																								<li>
																									<p>Event Length</p>
																									<span><?php echo $all_event['event_length']; ?></span>
																								</li>
																								<li>
	                                                <p>Capacity</p>
	                                                <span><?php echo $all_event['event_capacity']; ?></span>
	                                              </li>
				                                        <li>
				                                            <p>Loaction</p>
																										<?php
																											$location_where=array('location_id' => $all_event['location_id']);
																												$getalllocation = getSelectTable('location',$location_where, $con);
																												$all_location=mysqli_fetch_array($getalllocation,MYSQLI_BOTH);
																										?>
																										<span><?php echo $all_location['location_name']; ?> </span>
				                                        </li>
	                                            </ul>
	                                         </div>
	                                     </div>
	                                    <div class="event-right-btn review_define">
	                                      <a class="btn btn-danger" href="review.php?id=<?php echo $all_event['event_id']; ?>">review</a>
																				<a class="btn btn-danger" href="view_review.php?id=<?php echo $all_event['event_id']; ?>">view review</a>
	                                    </div>

	                              	</div>
																<?php
																	}
																}
																else {
																	?>
																	<h5 class="alert alert-danger">Sorry! No Past event Found</h5>

																	<?php
																}
																?>
                            </div>
                            </div>
                        </div>
                    </div>
										<div class="pagination_wraper">
			 						 <?php
									 	$sql = "SELECT COUNT(e.event_id) FROM reservation r INNER JOIN event e ON r.event_id = e.event_id
										 WHERE r.user_id =$user_id AND DATE(`event_time`)<= CURDATE()";
			 							 $rs_result = mysqli_query($con,$sql);
			 							 $row =mysqli_fetch_row($rs_result);
			 							 $total_records = $row[0];
			 							 $total_pages = ceil($total_records / $setLimit);
			 							 $pagLink = "<div class='pagination'>";
			 							 for ($i=1; $i<=$total_pages; $i++) {
			 								 $active='';
			 								 if($page==$i)
			 								 {
			 									 $active="active";
			 								 }
			 								 $pagLink .= "<a class='$active' href=".htmlspecialchars($_SERVER["PHP_SELF"])."?res_page=".$res_page."&page=".$i.">".$i."</a>";
			 							 };
										 if($total_records>1)
										 {
											 echo $pagLink . "</div>";
										 }

			 							 ?>
			 						 </div>
                </div>
             </div>
        </div>
    </section>
    <?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script src="<?php echo $path; ?>assets/js/bootstrap-datepicker.min.js"	 type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
       	$('#event_date').datepicker({

    	});
    });
</script>
</body>
</html>
