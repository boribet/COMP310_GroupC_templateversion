<?php
	$loginPage = true;
	include("include/config.php");
	if(!isLogin())
	{
		//header("location:index.php");
		//exit();
	}
	if(isset($_GET["page"]))
	{
		$page = (int)$_GET["page"];
	}
	else
	{
		$page = 1;
	}
	$setLimit = 12;
	if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
	$start_from = ($page-1) * $setLimit;
	$pageLimit 	= ($page * $setLimit) - $setLimit;
	$user_id 		= $_SESSION['userId'];

	$serch_data	= getValue($con,'serch_data');

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::Search Result</title>
<?php include("include/common-css.php"); ?>
<link href="<?php echo $path; ?>assets/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">

</head>

<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
             <div class="create-event">
             	<div class="container">
                	<div class="create-event-main">
                    	<div class="event-inner">
                				<div class="create-event-head">
                          <div class="event-title">
                              <h3>Search Result</h3>
                          </div>
                        </div>
                    		<div class="browse-event-block">
                      		<div class="event-list">
                          	<div class="search_result">
                              <div class="event-list-table">
																<ul>
																	<?php
																		$getall_data=mysqli_query($con,"SELECT c.category_id,
																		f.film_id,f.title,
																		e.event_id, e.event_name,e.event_id,e.event_description
																		FROM    category c
																		INNER JOIN film f
																				ON c.category_id = f.category_id
																		INNER JOIN event e
																				ON e.film_id = e.film_id
															WHERE DATE(`event_time`) >= CURDATE() AND c.category LIKE '%" . $serch_data . "%'
																	LIMIT $start_from, $setLimit");
																	$total_row=mysqli_num_rows($getall_data);
																	if($total_row>=1){
																		while($all_event = mysqli_fetch_array($getall_data,MYSQLI_BOTH))
																		{
																		?>
																		<li>
			                                <a href="book_event.php?id=<?php echo $all_event['event_id']; ?>">
																				<div class="event-title">
							                              <h5><?php echo $all_event['event_name']; ?></h5>
							                          </div>
																				<p><?php echo $all_event['event_description']; ?></p>
																				<p>Film Name: <?php echo $all_event['title']; ?></p>
																			</a>
																		</li>
		                                <?php
																			}
																		}
																		else{
																		?>
																			<li>
																				<p>Sorry! No data Found</p>
																			</li>
																	<?php
																	}
																 ?>
												 				</ul>
														 	</div>
														</div>
													</div>
                        </div>
                      </div>
                    </div>

										<div class="pagination_wraper">
										 <?php
										 $getall_data=mysqli_query($con,"SELECT  c.category_id,
										 f.film_id,f.title,
										 e.event_id,e.event_name,e.event_id,e.event_description
										 FROM    category c
										 INNER JOIN film f
												 ON c.category_id = f.category_id
										 INNER JOIN event e
												 ON e.film_id = e.film_id
							 WHERE DATE(`event_time`) >= CURDATE() AND c.category LIKE '%" . $serch_data . "%'");
									 		$total_records=mysqli_num_rows($getall_data);
											 $total_pages = ceil(($total_records-1) / $setLimit);
											 $pagLink = "<ul class='pagination'>";
											 for ($i=1; $i<=$total_pages; $i++) {
												 $active='';
												 if($page==$i)
												 {
													$pagLink .= "<li class='active'><a>".$i."</a>";
												 }
												 else {
												 $pagLink.="<li><a href=".htmlspecialchars( $_SERVER["PHP_SELF"]). "?serch_data=".$serch_data."&page=".$i."> ".$i."</a>";
												 }
											 };
											 echo $pagLink . "</div>";
											 ?>
										</div>
                </div>
             </div>
        </div>
    </section>
    <?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script src="<?php echo $path; ?>assets/js/bootstrap-datepicker.min.js"	 type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
       	$('#event_date').datepicker({});
    });
</script>
</body>
</html>
