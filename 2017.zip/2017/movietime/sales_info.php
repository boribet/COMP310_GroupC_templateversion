<?php
	$loginPage = true;
	include("include/config.php");
	if(!isLogin())
	{
		header("location:login.php");
		exit();
	}
	$ini_event_id	= getValue($con,'id');
	$user_id = $_SESSION['userId'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::Event reservation</title>
<?php include("include/common-css.php"); ?>
<link href="<?php echo $path; ?>assets/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">

</head>

<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
             <div class="create-event">
             	<div class="container">
                	<div class="create-event-main">
                    	<div class="event-inner">
                			<div class="create-event-head">
                           	 	<div class="event-title">
                                <h3>Sales information</h3>
                            </div>
                        	</div>
                    		<div class="browse-event-block">
                                <form>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Select Event:</label>
                                                <div class="form-group-inner">
                                                    <select id="event_box">
																											<?php
																											$event_where=array('hostuser_id' => $user_id);
																											$getall_event = getSelectTable('event',$event_where,$con);
																											while($all_event = mysqli_fetch_array($getall_event,MYSQLI_BOTH))
																											{
																												$selected="";
																												if ($all_event['event_id'] == $ini_event_id ){
																													$selected="selected";
																												}
																												?>
																													<option value="<?php echo $all_event['event_id']; ?>" <?php echo $selected; ?>><?php echo $all_event['event_name']; ?></option>
																											<?php
																										 		}
																											?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                        	</div>
													<div class="" id="sales_info">

													</div>
                        </div>
                    </div>
                </div>
             </div>
        </div>
    </section>
    <?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script src="<?php echo $path; ?>assets/js/bootstrap-datepicker.min.js"	 type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
			getsales_info(<?php echo $ini_event_id; ?>);
      $('#event_date').datepicker({
    	});
			$('#event_box').on('change',function(){
				var event_id=$('#event_box').val();
				getsales_info(this.value);
			});
    });
		function getsales_info(event)
		{
			var event_id=event;
			$.ajax({
				type:"POST",
				url:"ajax.php",
				data:{data_type:"getsales_info", event_id:event_id},
				success: function(result)
				{
					$('#sales_info').html(result);
				}
			});
		}
</script>
</body>
</html>
