<?php
	$loginPage = true;
	include("include/config.php");
	if(!isLogin())
	{
		header("location:login.php");
		exit();
	}
	$setLimit = 4;
	if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
	$start_from = ($page-1) * $setLimit;
	$pageLimit = ($page * $setLimit) - $setLimit;
	$user_id = $_SESSION['userId'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::Event hosted</title>
<?php include("include/common-css.php"); ?>
<link href="<?php echo $path; ?>assets/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">

</head>

<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
             <div class="create-event">
             	<div class="container">
                	<div class="create-event-main">
                    	<div class="event-inner">
                			<div class="create-event-head">
                                <div class="event-title">
                                    <h3>events hosted by you</h3>
                                </div>
                            <div class="event-right-btn">
                                <a class="btn btn-danger" href="create_event.php">creat event</a>
                            </div>
                        </div>
												<?php include 'include/message.php';?>
                    		<div class="browse-event-block">
                        		<form>
															<?php
															$getall_event=mysqli_query($con,"SELECT * FROM event WHERE hostuser_id =$user_id ORDER BY event_id DESC LIMIT $start_from, $setLimit");
															if(mysqli_num_rows($getall_event)>0)
															{
															while($all_event = mysqli_fetch_array($getall_event,MYSQLI_BOTH))
															{
															?>
                            	<div class="event-list">
                                    <div class="event-list-left">
                                        <div class="event-title">
                                            <h5><?php echo $all_event['event_name']; ?></h5>
                                        </div>
                                        <div class="event-list-table">
                                            <ul>
																							<li>
			                                           <p>Film</p>
																								 <?php
				 																						$film_where=array('film_id' => $all_event['film_id']);
				 																						$getallfilm = getSelectTable('film',$film_where, $con);
				 																						$all_film = mysqli_fetch_array($getallfilm,MYSQLI_BOTH);
				 																					?>
				 																				<span><?php echo $all_film['title']; ?></span>
			                                        </li>
			                                        <li>
		                                            <p>Event Date</p>
		                                            <span><?php echo $all_event['event_time']; ?></span>
			                                        </li>
																							<li>
																								<p>Event Length</p>
																								<span><?php echo $all_event['event_length']; ?></span>
																							</li>
			                                        <li>
		                                            <p>Loaction</p>
																								<?php
																										$location_where=array('location_id' => $all_event['location_id']);
																										$getalllocation = getSelectTable('location',$location_where, $con);
																										$all_location=mysqli_fetch_array($getalllocation,MYSQLI_BOTH);
																								?>
																								<span><?php echo $all_location['location_name']; ?> </span>
			                                        </li>
                                              <li>
                                                <p>Capacity</p>
                                                <span><?php echo $all_event['event_capacity']; ?></span>
                                              </li>
                                            </ul>
                                         </div>
                                        </div>
                                        <div class="event-right-btn">
                                          <a class="btn btn-danger" href="sales_info.php?id=<?php echo $all_event['event_id']; ?> ">Sales info</a>
                                        </div>
                                  </div>
                                <?php
																	}
																}
																else {
																	?>
																	<h5 class="alert alert-danger">You have not create any event</h5>
																<?php
																}
																?>
                            </form>
                        	</div>
                        </div>
                    </div>
										<div class="pagination_wraper">
										<?php
										$where=array('hostuser_id' => $user_id);
										echo displayPaginationBelow($setLimit,$page,'event',$where,$con);
											?>
										</div>
                </div>
             </div>
        </div>
    </section>
    <?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script src="<?php echo $path; ?>assets/js/bootstrap-datepicker.min.js"	 type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
       	$('#event_date').datepicker({});
    });
</script>
</body>
</html>
