<?php
	$loginPage = true;
	include("include/config.php");
	if(!isLogin())
	{
		header("location:login.php");
		exit();
	}
	$message='';
	$event_id	= getValue($con,'id');
	if(!$event_id)
	{
		header("location:browse_event.php");
		exit();
	}

	$user_id	= $_SESSION['userId'];
	if(isset($_POST['book_event']))
	{
		$event_id	= getValue($con,'id');
		$reservation_where=array('event_id' => $event_id, 'user_id'=>$user_id);
		$booksit_count = getCount('reservation',$reservation_where, $con);
		if ($booksit_count>=1) {
			$message='<p class="alert alert-danger">You have already booked this event! </p>';
		}
		else {
			$date			= date("Y-m-d H:i:s");
			$form_data=array(
					'user_id'				=> $user_id,
					'event_id'			=> $event_id,
					'purchase_date'	=> $date
			);
				dbRowInsertWithLastId('reservation', $form_data, $con);
				$user_where		= array('user_id' => $user_id);
				$getall_user 	= getSelectTable('user',$user_where, $con);
				$all_user 		= mysqli_fetch_array($getall_user,MYSQLI_BOTH);
				$email 				= $all_user['email'];
				$event_where	= array('event_id' => $event_id);
				$getall_event = getSelectTable('event',$event_where, $con);
				$all_event 		= mysqli_fetch_array($getall_event,MYSQLI_BOTH);
				$event_name		= $all_event['event_name'];
				$price				= $all_event['price'];
				$event_time		=	$all_event['event_time'];
				$location_where= array('location_id' => $all_event['location_id']);
				$getall_location= getSelectTable('location',$location_where, $con);
				$all_location	= mysqli_fetch_array($getall_location,MYSQLI_BOTH);
				$location_name= $all_location['location_name'];
				$film_where		= array('film_id' => $all_event['film_id']);
				$getall_film 	= getSelectTable('film',$film_where, $con);
				$all_film 		= mysqli_fetch_array($getall_film,MYSQLI_BOTH);
				$film_name		= $all_film['title'];
				$imdb_rating	= $all_film['imdb_rating'];

				$subject 	= "MovieTime Event Book";
        $message  = '<html><body><table style="table-layout:fixed;">';
        $message .= '<tr><td colspan="2" align="center"><h1 style="color:#000; font-size:18px;"> You have registered to:<span style="font-size:18px; color:gray;">'.$event_name .'</span> event</h1></td></tr>';
				$message .= '<tr><td colspan="2" align="center"><h1 style="color:#000; font-size:18px;">Event Location:<span style="font-size:18px; color:gray;">'.$location_name .'</span> </h1></td></tr>';
				$message .= '<tr><td colspan="2" align="center"><h1 style="color:#000; font-size:18px;"> Event Date and time:<span style="font-size:18px; color:gray;">'.$event_time .'</span> </h1></td></tr>';
				$message .= '<tr><td colspan="2" align="center"><h1 style="color:#000; font-size:18px;">Price:<span style="font-size:18px; color:gray;">$'.$price .'</span> </h1></td></tr>';
				$message .= '<tr><td colspan="2" align="center"><h1 style="color:#000; font-size:14px;"> Movie Name : <span style="font-size:14px; color:gray;">'.$film_name .'</span></h1>';
				$message .= '<tr><td colspan="2" align="center"><h1 style="color:#000; font-size:18px;">IMDB Rating:<span style="font-size:18px; color:gray;">'.$imdb_rating .'</span></h1></td></tr>';
				$message .= '</tr></table></body></html>';
				// Set content-type header for sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: MovieTime' . "\r\n";

				mail($email,$subject,$message,$headers);
				setMessage("Event booked succesfully! We will send a reminder the day before! ","alert alert-success");
				header("location:my_reservation.php");
				exit();
		}
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::book Event</title>
<?php include("include/common-css.php"); ?>
<link href="<?php echo $path; ?>assets/css/fontawesome-stars.css" rel="stylesheet" type="text/css">

</head>

<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
					<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
             <div class="create-event">
             	<div class="container">
                	<div class="create-event-main book-event-block">
                    	<div class="event-inner">
                			<div class="create-event-head">
                    		<div class="event-title">
                                <h3>Book events</h3>
                            </div>
                        </div>
												<div class="browse-event-block">
                        		<div class="row">
                                	<div class="col-md-6">
                                    	<div class="form-group">
                                        	<label>Select Event:</label>
                                            <div class="form-group-inner">
                                            	<select name="id" onchange="change_event(this)">
																								<?php
																								$getall_event=mysqli_query($con,"SELECT * FROM `event` WHERE DATE(`event_time`) >= CURDATE() ORDER BY 'event_id'");
																								//$getall_event = get_all_data('event', $con);
																								while($all_event = mysqli_fetch_array($getall_event,MYSQLI_BOTH))
																								{
																									$selected="";
																									if ($all_event['event_id'] == $event_id ){
																										$selected="selected";
																									}
																								?>
	                                            		<option value="<?php echo $all_event['event_id']; ?>" <?php echo $selected;?>><?php echo $all_event['event_name']; ?></option>
                                                <?php
																								}
																							?>
                                            </select>
                                            </div>
                                        </div>
                                    </div>
                            	</div>
                        </div>
												<div class="" id="bookevent_response">
													<?php echo $message; ?>
													<?php include 'include/message.php';?>
												</div>
												<div class="" id="singleevent_response">

												</div>

												</div>
                    </div>
                </div>
             </div>
					</form>
        </div>
    </section>
    <?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script src="<?php echo $path; ?>assets/js/jquery.barrating.min.js"	 type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
 		$('.ratingbar').barrating('show', {
		  theme: 'my-awesome-theme',
		});
		event_default(<?php echo $event_id; ?>);
		unsetmessage('#bookevent_response',6000);
    });
		function unsetmessage(id,timeout){
			setTimeout(function(){
				$(id).html('');
			},timeout);
		}
		function change_event(event)
		{
			$('#bookevent_response').html('');
			var event_id=event.value;
			$.ajax({
	      type:"POST",
	      url:"ajax.php",
	      data:{data_type:"getsingle_eventdata", event_id:event_id},
	      success: function(result)
	      {
	        $('#singleevent_response').html(result);
	      }
    	});
		}
		function event_default(event)
		{
			var event_id=event;
			$.ajax({
	      type:"POST",
	      url:"ajax.php",
	      data:{data_type:"getsingle_eventdata", event_id:event_id},
	      success: function(result)
	      {
	        $('#singleevent_response').html(result);
	      }
    	});
		}
		function book_event(event_id)
		{
			var event_id=event_id;
			$.ajax({
	      type:"POST",
	      url:"ajax.php",
	      data:{data_type:"book_event", event_id:event_id},
	      success: function(result)
	      {
	        $('#bookevent_response').html(result);
	      }
    	});
		}
</script>
</body>
</html>
