<?php
	$loginPage = true;
	include("include/config.php");
	if(!isLogin())
	{
		header("location:login.php");
		exit();
	}
	$ini_event_id	= getValue($con,'id');
	$setLimit = 4;
	if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
	$start_from = ($page-1) * $setLimit;
	$pageLimit = ($page * $setLimit) - $setLimit;
	$user_id = $_SESSION['userId'];
	$event_where=array('event_id' =>$ini_event_id);
	$getallevent = getSelectTable('event',$event_where, $con);
	$all_event = mysqli_fetch_array($getallevent,MYSQLI_BOTH);
	$event_name=$all_event['event_name'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::Event hosted</title>
<?php include("include/common-css.php"); ?>
<link href="<?php echo $path; ?>assets/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo $path; ?>assets/css/fontawesome-stars.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
             <div class="create-event">
             	<div class="container">
                	<div class="create-event-main">
                    	<div class="event-inner">
                			<div class="create-event-head">
                          <div class="event-title">
                              <h3>Event review</h3>
                          </div>

                        </div>
												<div class="create-event-head">
	                          <div class="event-title">
	                              <h5><?php echo $event_name; ?></h5>
	                          </div>
	                        </div>
												<?php include 'include/message.php';?>
                    		<div class="browse-event-block">
                        		<form>
															<?php
															$getall_review=mysqli_query($con,"SELECT * FROM feedback WHERE event_id =$ini_event_id	LIMIT $start_from, $setLimit");
															if(mysqli_num_rows($getall_review)>0)
															{
															while($all_review = mysqli_fetch_array($getall_review,MYSQLI_BOTH))
															{
															?>
                            	<div class="event-list view_reviews">
                                    <div class="event-list-left">
                                        <div class="event-title">
																						<?php
																						$user_where		= array('user_id' => $all_review['user_id']);
																						$getall_user 	= getSelectTable('user',$user_where, $con);
																						$all_user 		= mysqli_fetch_array($getall_user,MYSQLI_BOTH);
																						?>
                                            <h5><?php echo $all_user['first_name'].' '.$all_user['last_name']; ?></h5>
                                        </div>
                                        <div class="event-list-table">
                                            <ul>
																							<li>
                                                <p>Rating</p>
																								<div class="br-wrapper br-theme-fontawesome-stars">
																										<?php
																										$rating=$all_review['rating'];
																										?>
																										<select class="view_review">
																											<?php
																												for($i=1;$i<=5;$i++)
																												{
																													$selected="";
																													if($rating==$i)
																													{
																														$selected="selected";
																													}
																											 ?>
																												<option value="<?php echo $i; ?>" <?php echo $selected ?>><?php echo $i; ?></option>
																											<?php
																										 		}
																											?>
																										</select>
																								</div>

                                              </li>
																							<li>
		                                            <p>Description</p>
																								<span><?php echo $all_review['notes']; ?> </span>
			                                        </li>
                                            </ul>
                                         </div>
                                        </div>
                                  </div>
                                <?php
																	}
																}
																else {
																	?>
																	<h5 class="alert alert-danger">You have not create any event</h5>
																<?php
																}
																?>
                            </form>
                        	</div>
                        </div>
                    </div>
										<div class="pagination_wraper">
										<?php
										$where=array('event_id' => $ini_event_id);
										echo displayPaginationBelow($setLimit,$page,'feedback',$where,$con);
											?>
										</div>
                </div>
             </div>
        </div>
    </section>
    <?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script src="<?php echo $path; ?>assets/js/bootstrap-datepicker.min.js"	 type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
       	$('#event_date').datepicker({});
    });
</script>
<script src="<?php echo $path; ?>assets/js/jquery.barrating.min.js"	 type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
       	$('.view_review').barrating('show', {
			  theme: 'my-awesome-theme',
			  readonly: 'state'
		});
    });
</script>
</body>
</html>
