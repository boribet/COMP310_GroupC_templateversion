<?php
	$loginPage = true;
	include("include/config.php");
	if(!isLogin())
	{
		header("location:login.php");
		exit();
	}
	$ini_event_id	= getValue($con,'id');
	$user_id = $_SESSION['userId'];
	if(isset($_POST['review_event']))
	{
		$event_id					= getValue($con,'event_id');
		$rating						= getValue($con,'rating');
		$notes						= getValue($con,'notes');
		$form_data=array(
				'user_id'				=> $user_id,
				'event_id'			=> $event_id,
				'rating'				=> $rating,
				'notes'					=> $notes,
				'review_date'	=> date("Y-m-d H:i:s")
		);
		$user_id=dbRowInsertWithLastId('feedback', $form_data, $con);
		setMessage("Your review send Successfylly","alert alert-success");
		header("location:my_reservation.php");
		exit();
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Movie::Event review</title>
<?php include("include/common-css.php"); ?>
<link href="<?php echo $path; ?>assets/css/fontawesome-stars.css" rel="stylesheet" type="text/css">

</head>

<body>
<div class="wrapper">
	<?php include("include/header.php"); ?>
	<section>
    	<div class="section-main">
             <div class="create-event">
             	<div class="container">
                	<div class="create-event-main">
                    	<div class="create-event-inner">
                    		<div class="event-inner">
                                <div class="browse-event-block">
																		<?php include 'include/message.php';?>
                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                        <div class="create-event-head">
                                            <div class="event-title">
                                                <h3>write a review</h3>
                                            </div>
                                            <div class="event-right-btn">
                                                <button type="submit" name="review_event" class="btn btn-danger">send</button>
                                            </div>
                                        </div>
                                        <div class="review-event">
                                          <div class="form-group">
                                            <label>Select Event :</label>
                                            <div class="form-group-inner">
                                            <select name="event_id">
																							<?php
																								$reservation_where=array('user_id' => $user_id);
																								$getall_reservation = getSelectDistinctTable('reservation','event_id',$reservation_where, $con);
																						while($all_reservation =mysqli_fetch_array($getall_reservation,MYSQLI_BOTH))
																						{
																							$event_id=$all_reservation['event_id'];
																							$getall_event=mysqli_query($con,"SELECT * FROM `event` WHERE `event_id`='$event_id' AND DATE(`event_time`) < CURDATE() ORDER BY 'event_time'");
																							if(mysqli_num_rows($getall_event)>0)
																							{
																								$all_event = mysqli_fetch_array($getall_event,MYSQLI_BOTH);
																								$selected="";
																								if ($all_event['event_id'] == $ini_event_id ){
																									$selected="selected";
																								}
																								?>
																									<option value="<?php echo $all_event['event_id']; ?>" <?php echo $selected; ?>><?php echo $all_event['event_name']; ?></option>
																								<?php
																								}
																							}
																						?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Rating :</label>
                                                <div class="form-group-inner">
                                                    <div class="event-review">
                                                        <div class="br-wrapper br-theme-fontawesome-stars">
                                                        	<input type="hidden" class="event_review_value" name="rating" value="1">
                                                            <select class="event_review">
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                 <textarea name="notes"></textarea>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
             </div>
        </div>
    </section>
    <?php include 'include/footer.php' ?>
</div>
<?php include 'include/common-js.php' ?>
<script src="<?php echo $path; ?>assets/js/jquery.barrating.min.js"	 type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
       	$('.event_review').barrating('show', {
			  theme: 'my-awesome-theme',
			  onSelect: function(value, text, event) {
				if (typeof(event) !== 'undefined') {
				  $('.event_review_value').val(value);
				}
			  }
		});
    });
</script>
</body>
</html>
