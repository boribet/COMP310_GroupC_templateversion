<script src="<?php echo $path; ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo $path; ?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo $path; ?>assets/js/parsley.min.js"	 type="text/javascript"></script>
