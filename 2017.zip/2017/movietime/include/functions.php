<?php
function getLEVEL()
{
	global $_LEVEL;
	$level = $_LEVEL == 0 ? '' : '';
	$level = $_LEVEL > 0 ? str_repeat('../', $_LEVEL) : $level;
	return $level;
}

function getPath($path)
{
	return BASE_PATH.$path;
}

function setLEVEL($level = false)
{
	global $_LEVEL;
	$_LEVEL = $level ? $level : LEVEL;
}
function getURL($query = false)
{
	return BASE_PATH.$query;
}
function isLogin()
{
	if(!isset($_SESSION['userId']) || $_SESSION['userId']=='')
	{
		return false;
	}
	else
	{
		return true;
	}
}
function getValue($con,$key)
{
	$value = (isset($_REQUEST[$key]))?$_REQUEST[$key]:"";
	return  mysqli_real_escape_string($con,trim($value));
}
function setMessage($msg,$class="")
{
	$_SESSION['message'] = $msg;
	$_SESSION['message_type'] = $class;
}

function checkValidImage($name)
{
	$temp = explode(".",$name);
	$extension = end($temp);
	$allowedExts = array("jpeg", "jpg", "png","gif","pdf");

	if(in_array($extension, $allowedExts))
	{
		return true;
	}
	else
	{
		setMessage("Only jpeg,jpg,png,gif,pdf file allow","label-danger");
		return false;
	}
}

function checkValidImagePdf($name)
{
	$temp = explode(".",$name);
	$extension = end($temp);
	$allowedExts = array("jpeg", "jpg", "png","gif","pdf");

	if(in_array($extension, $allowedExts))
	{
		return true;
	}
	else
	{
		setMessage("Only jpeg,jpg,png,gif,pdf file allow","label-danger");
		return false;
	}
}

function checkValidPDF($name)
{
	$temp = explode(".",$name);
	$extension = end($temp);
	$allowedExts = array("pdf");

	if(in_array($extension, $allowedExts))
	{
		return true;
	}
	else
	{
		setMessage("Only PDF file allow","label-danger");
		return false;
	}
}

function is_valid_email($email)
{
	$result = false;

	if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
		$result = true;
	}
	if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $email))
	{
		$result = FALSE;
	}
	return $result;
}
function valid_pass($password) {
if (!preg_match_all('$\S*(?=\S{8,32})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[\W])\S*$', $password))
	{
		return FALSE;
	}
	else
	{
		if(strlen($password) < 32)
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
}

function checkValidVedio($name)
{
	$temp = explode(".",$name);
	$extension = end($temp);
	//$allowedExts = array("mpeg", "mpg", "avi", "mov","asf","asx","wmv","wma","wmx","rm","mp4","3gp","ogm","mkv","mpeg-4","MPEG-4");
	$allowedExts = array("mp4");
	if (in_array($extension, $allowedExts))
	{
		return true;
	}
	else
	{
		setMessage("Only MP4 Video file Allowed","label-danger");
		return false;
	}
}

function getCurrentDateTime()
{
	return date('Y-m-d H:i:s');
}

function mysql2date($date){
	if ($date != ""){
		$splitArray = explode("-",$date);
		$newDate = $splitArray[1] . "/" . $splitArray[2] . "/" . $splitArray[0];
		return $newDate;
	}else{
		return "";
	}
}

function date2mysql($date){
	$splitArray = explode("/",$date);
	$newDate = $splitArray[2] . "-" . $splitArray[0] . "-" . $splitArray[1];
	return $newDate;
}


//image resize and scale
function createThumbnail($image_name,$new_width,$new_height,$uploadDir,$moveToDir)
{
	$path = $uploadDir . '/' . $image_name;
	$mime = getimagesize($path);

    if($mime['mime']=='image/png'){ $src_img = imagecreatefrompng($path); }
    if($mime['mime']=='image/jpg'){ $src_img = imagecreatefromjpeg($path); }
    if($mime['mime']=='image/jpeg'){ $src_img = imagecreatefromjpeg($path); }
    if($mime['mime']=='image/pjpeg'){ $src_img = imagecreatefromjpeg($path); }

    $old_x          =   imageSX($src_img);
    $old_y          =   imageSY($src_img);

    if($old_x > $old_y)
    {
        $thumb_w    =   $new_width;
        $thumb_h    =   $old_y*($new_height/$old_x);
    }

    if($old_x < $old_y)
    {
        $thumb_w    =   $old_x*($new_width/$old_y);
        $thumb_h    =   $new_height;
    }

    if($old_x == $old_y)
    {
        $thumb_w    =   $new_width;
        $thumb_h    =   $new_height;
    }

    $dst_img        =   ImageCreateTrueColor($thumb_w,$thumb_h);

    imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);


    // New save location
	$new_thumb_name='thumb_'. $image_name;
    $new_thumb_loc = $moveToDir .$new_thumb_name;

    if($mime['mime']=='image/png'){ $result = imagepng($dst_img,$new_thumb_loc,8); }
    if($mime['mime']=='image/jpg'){ $result = imagejpeg($dst_img,$new_thumb_loc,80); }
    if($mime['mime']=='image/jpeg'){ $result = imagejpeg($dst_img,$new_thumb_loc,80); }
    if($mime['mime']=='image/pjpeg'){ $result = imagejpeg($dst_img,$new_thumb_loc,80); }

    imagedestroy($dst_img);
    imagedestroy($src_img);
    return $new_thumb_name;
}
function generateCode($qtd){
//Under the string $Caracteres you write all the characters you want to be used to randomly generate the code.
$Caracteres = '0123456789';//$Caracteres = 'ABCDEFGHIJKLMOPQRSTUVXWYZ0123456789';
$QuantidadeCaracteres = strlen($Caracteres);
$QuantidadeCaracteres--;

$Hash=NULL;
		for($x=1;$x<=$qtd;$x++){
				$Posicao = rand(0,$QuantidadeCaracteres);
				$Hash .= substr($Caracteres,$Posicao,1);
		}

return $Hash;
}

	//image comprased
/*	function compress($source, $destination, $quality)
	{
		$info = getimagesize($source);

		if ($info['mime'] == 'image/jpeg')
			$image = imagecreatefromjpeg($source);

		elseif ($info['mime'] == 'image/gif')
			$image = imagecreatefromgif($source);

		elseif ($info['mime'] == 'image/png')
			$image = imagecreatefrompng($source);

		imagejpeg($image, $destination, $quality);
		return $destination;
	}
*/
	//$imagequality = ($image_size / 1048576)*10;
	//$imagequality = ceil($imagequality);
	//$newimage = compress($tmp_filename, $uploadedfile.$img_name, $imagequality);
