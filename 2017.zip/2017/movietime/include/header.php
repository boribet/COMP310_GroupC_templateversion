<?php
$id  = isset($_SESSION['userId']);
?>
<header class="header">
    <div class="header-inner">
        <div class="header-left">
            <div class="header-left-wrap">
              <div class="header-logo">
                <a href="index.php"><img src="assets/images/MTlogo.JPG" alt="logo" class="img-responsive"></a>
              </div>
              </div>
            <div class="header-right">
              <div class="header-right-inner">
                  <div class="header-menu">
                      <nav class="navbar">
                        <div class="navbar-header">
                          <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                              <span class="sr-only">Toggle navigation</span>
                              <span class="icon-bar"></span>
                              <span class="icon-bar"></span>
                              <span class="icon-bar"></span>
                          </button>
                        </div>
                        <div id="navbarCollapse" class="collapse navbar-collapse">
                            <ul class="nav navbar-nav">
                                <li  class="active"><a href="browse_event.php">Browse events</a></li>
                                <?php if(isset($_SESSION['userId'])){?>
                                  <li><a href="event_hosted.php">My events</a></li>
                                  <li><a href="my_reservation.php">My reservations</a></li>
                                  <li class="dropdown">
                                    <a data-toggle="dropdown" class="dropdown-toggle" href="#"> My profile  <b class="caret"></b></a>
                                    <ul class="dropdown-menu">
                                         <li><a href="profile.php">Go to my profile</a></li>
                                         <li><a href="logout.php">Log out</a></li>
                                    </ul>
                                  </li>
                                  <?php
                                  }
                                  else{
                                 ?>
                                 <li><a href="login.php">LogIn/Registration</a></li>
                               <?php } ?>
                            </ul>
                        </div>
                      </nav>
                  </div>
                  <div class="header-search">
                      <form method="get" action="search.php">
                          <div class="header-search-inner">
                              <input type="text" id="search_box" name="serch_data" placeholder="Search for categories of events" class="form-control" required>
                              <button type="submit" id="search_btn" class="btn btn-danger">Search</button>
                          </div>
                      </form>
                  </div>

              </div>
              </div>
          </div>
      </div>
  </header>
