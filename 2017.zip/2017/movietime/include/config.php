<?php
	session_start();
	error_reporting(E_ALL ^ E_DEPRECATED);
	defined('APP_NAME') || define('APP_NAME', 'MovieTime');
	defined('APP_VERSION') || define('APP_VERSION', 'v1.0');

	$hostname 	= 'localhost';
	$username 	= 'root';
	$password 	= '';
	$database 	= 'film_night';
	$path     	= 'http://localhost/2017/movietime/';
	define('IMAGE_UPLOAD_PATH',$_SERVER['DOCUMENT_ROOT'].'/2017/movietime/upload/');
	define('IMAGE_UPLOADED_PATH',$_SERVER['DOCUMENT_ROOT'].'/2017/movietime/upload/');


	$con = mysqli_connect($hostname,$username,$password,$database) or die(mysqli_error());
	define('BASE_PATH',$path);
	define('SITE_URL',$path);

	require_once 'functions.php';
	require_once 'database_function.php';
	if(!isLogin() && !$loginPage)
	{
		header("location:login.php");
		exit();
	}
?>
