<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <link href="<?php echo $path; ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo $path; ?>assets/fonts/font-awesome.css" rel="stylesheet" type="text/css">
  <link href="<?php echo $path; ?>assets/fonts/fonts.css" rel="stylesheet" type="text/css">
  <link href="<?php echo $path; ?>assets/css/animate.css" rel="stylesheet" type="text/css">
  <link href="<?php echo $path; ?>assets/css/parsley.css" rel="stylesheet" type="text/css">
  <link href="<?php echo $path; ?>assets/css/stylesheet.css" rel="stylesheet" type="text/css">
