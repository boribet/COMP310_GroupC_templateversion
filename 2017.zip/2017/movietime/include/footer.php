<footer>
  <div class="footer-main">
      <div class="footer-bottom">
          <div class="container">
              <div class="footer-copyright">
                  <p>© 2017 Web Development - Group C</p>
                </div>
            </div>
        </div>
    </div>
</footer>
