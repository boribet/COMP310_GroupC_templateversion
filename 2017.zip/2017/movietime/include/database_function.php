<?php
/**insertdata function start**/
function dbRowInsert($table_name,$form_data,$con)
{
	$fields = array_keys($form_data);
    $sql = "INSERT INTO ".$table_name."
    (`".implode('`,`', $fields)."`)
    VALUES('".implode("','", $form_data)."')";

	mysqli_query($con,"SET names utf8");
	return mysqli_query($con,$sql) or die(mysqli_error($con));
}
/**insert data function end**/

/**insertdata function start**/
function dbRowInsertWithLastId($table_name,$form_data,$con)
{
	$fields = array_keys($form_data);
    $sql = "INSERT INTO ".$table_name."
    (`".implode('`,`', $fields)."`)
    VALUES('".implode("','", $form_data)."')";

	mysqli_query($con,"SET names utf8");
	mysqli_query($con,$sql) or die(mysqli_error($con));
	$last_id = mysqli_insert_id($con);
	return $last_id;
}
/**insert data function end**/

/**update data function start**/
function dbRowUpdate($table_name, $form_data, $where_clause='',$con)
{
 // check for optional where clause
	$whereSQL =  array();
    if(!empty($where_clause))
    {
		foreach($where_clause as $column => $value)
		{
			$whereSQL[] = "`".$column."` = '".$value."'";
		}
    }
    // start the actual SQL statement
    $sql = "UPDATE ".$table_name." SET ";

    // loop and build the column /
    $sets = array();
    foreach($form_data as $column => $value)
    {
		$sets[] = "`".$column."` = '".$value."'";
    }
    $sql .= implode(', ', $sets);

    // append the where statement
    $sql .= ' WHERE ' . implode(' AND ', $whereSQL);
 	// run and return the query result
    mysqli_query($con,"SET names utf8");
	return mysqli_query($con,$sql);
}

function getCount($table_name ,$where_clause='', $con)
{
	$whereSQL = array();
    if(!empty($where_clause))
    {
		foreach($where_clause as $column => $value)
		{
			$whereSQL[] = "`".$column."` = '".$value."'";
		}
    }

    $sql = "SELECT * FROM ".$table_name ;
    $sql .= ' WHERE ' . implode(' AND ', $whereSQL);

	$count_row='';
	$result=mysqli_query($con,$sql);
	$count_row= mysqli_num_rows($result);
	return $count_row;
}

function getSelectTable($table_name ,$where_clause='', $con)
{
    $whereSQL =  array();
    if(!empty($where_clause))
    {
		  foreach($where_clause as $column => $value)
		  {
			   $whereSQL[] = "`".$column."` = '".$value."'";
		  }
    }

  $sql = "SELECT * FROM ".$table_name ;
	$sql .= ' WHERE ' . implode(' AND ', $whereSQL);
	mysqli_query($con,"SET names utf8");
	$result=mysqli_query($con,$sql);
	return $result;
}

function getSelectValueTable($table_name, $column_name, $where_clause='', $con)
{
  $whereSQL =  array();
  if(!empty($where_clause))
  {
	  foreach($where_clause as $column => $value)
	  {
		   $whereSQL[] = "`".$column."` = '".$value."'";
	  }
  }

  $sql = "SELECT ".$column_name." FROM ".$table_name ;
	$sql .= ' WHERE ' . implode(' AND ', $whereSQL);
	mysqli_query($con,"SET names utf8");
	$query=mysqli_query($con,$sql);

	$result = '';
	while($data = mysqli_fetch_array($query,MYSQLI_BOTH))
	{
		$result = $data[$column_name];
	}
	return $result;
}

function delete_table_row($table_name, $where_clause='', $con)
{
	$whereSQL =  array();
	if(!empty($where_clause))
	{
		foreach($where_clause as $column => $value)
		{
			$whereSQL[] = "`".$column."` = '".$value."'";
		}
	}

	$sql = "DELETE FROM ".$table_name ;
	$sql .= ' WHERE ' . implode(' AND ', $whereSQL);
	$result=mysqli_query($con,$sql);
	return $result;
}

function get_all_data($table_name, $con)
{
	mysqli_query($con,"SET names utf8");
	$sql = "SELECT * FROM ".$table_name ;
	$result=mysqli_query($con,$sql);
	return $result;
}
function getSelectDistinctTable($table_name ,$columnname, $where_clause='', $con)
{
    $whereSQL =  array();
    if(!empty($where_clause))
    {
    foreach($where_clause as $column => $value)
    {
      $whereSQL[] = "`".$column."` = '".$value."'";
    }
    }
		$sql = "SELECT DISTINCT $columnname FROM ".$table_name ;
		$sql .= ' WHERE ' . implode(' AND ', $whereSQL);
		mysqli_query($con,"SET names utf8");
		$result=mysqli_query($con,$sql);
		return $result;
}

function displayPaginationBelow($per_page,$page, $table_name,$where_clause='', $con){
 $page_url="?";
 $whereSQL =  array();
 if(!empty($where_clause))
 {
		foreach($where_clause as $column => $value)
		{
		 $whereSQL[] = "`".$column."` = '".$value."'";
		}
 }
	$query = "SELECT COUNT(*) as totalCount FROM ".$table_name;
	$query.=	' WHERE ' . implode(' AND ', $whereSQL);
	$rec = mysqli_fetch_array(mysqli_query($con,$query));
	$total = $rec['totalCount'];
  $adjacents = "2";

	$page = ($page == 0 ? 1 : $page);
	$start = ($page - 1) * $per_page;

	$prev = $page - 1;
	$next = $page + 1;
  $setLastpage = ceil($total/$per_page);
	$lpm1 = $setLastpage - 1;

	$setPaginate = "";
	if($setLastpage > 1)
	{
		$setPaginate .= "<ul class='pagination'>";
    //$setPaginate .= "<li class='setPage'>Page $page of $setLastpage</li>";
		if ($setLastpage < 7 + ($adjacents * 2))
		{
			for ($counter = 1; $counter <= $setLastpage; $counter++)
			{
				if ($counter == $page)
					$setPaginate.= "<li class='active'><a>$counter</a></li>";
				else
					$setPaginate.= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
			}
		}
		elseif($setLastpage > 5 + ($adjacents * 2))
		{
			if($page < 1 + ($adjacents * 2))
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$setPaginate.= "<li><a class='current_page'>$counter</a></li>";
					else
						$setPaginate.= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
				}
				$setPaginate.= "<li class='dot'>...</li>";
				$setPaginate.= "<li><a href='{$page_url}page=$lpm1'>$lpm1</a></li>";
				$setPaginate.= "<li><a href='{$page_url}page=$setLastpage'>$setLastpage</a></li>";
			}
			elseif($setLastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$setPaginate.= "<li><a href='{$page_url}page=1'>1</a></li>";
				$setPaginate.= "<li><a href='{$page_url}page=2'>2</a></li>";
				$setPaginate.= "<li class='dot'>...</li>";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$setPaginate.= "<li><a class='current_page'>$counter</a></li>";
					else
						$setPaginate.= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
				}
				$setPaginate.= "<li class='dot'>..</li>";
				$setPaginate.= "<li><a href='{$page_url}page=$lpm1'>$lpm1</a></li>";
				$setPaginate.= "<li><a href='{$page_url}page=$setLastpage'>$setLastpage</a></li>";
			}
			else
			{
				$setPaginate.= "<li><a href='{$page_url}page=1'>1</a></li>";
				$setPaginate.= "<li><a href='{$page_url}page=2'>2</a></li>";
				$setPaginate.= "<li class='dot'>..</li>";
				for ($counter = $setLastpage - (2 + ($adjacents * 2)); $counter <= $setLastpage; $counter++)
				{
					if ($counter == $page)
						$setPaginate.= "<li><a class='current_page'>$counter</a></li>";
					else
						$setPaginate.= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
				}
			}
		}

		if ($page < $counter - 1){
			$setPaginate.= "<li><a href='{$page_url}page=$next'>Next</a></li>";
      $setPaginate.= "<li><a href='{$page_url}page=$setLastpage'>Last</a></li>";
		}else{
			$setPaginate.= "<li><a class='current_page'>Next</a></li>";
          $setPaginate.= "<li><a class='current_page'>Last</a></li>";
        }
			$setPaginate.= "</ul>\n";
	}
    return $setPaginate;
}

function displayPaginationindex($per_page,$page, $table_name,$total, $con){
 $page_url="?";

  $adjacents = "2";

	$page = ($page == 0 ? 1 : $page);
	$start = ($page - 1) * $per_page;

	$prev = $page - 1;
	$next = $page + 1;
  $setLastpage = ceil($total/$per_page);
	$lpm1 = $setLastpage - 1;

	$setPaginate = "";
	if($setLastpage > 1)
	{
		$setPaginate .= "<ul class='pagination'>";
    //$setPaginate .= "<li class='setPage'>Page $page of $setLastpage</li>";
		if ($setLastpage < 7 + ($adjacents * 2))
		{
			for ($counter = 1; $counter <= $setLastpage; $counter++)
			{
				if ($counter == $page)
					$setPaginate.= "<li class='active'><a>$counter</a></li>";
				else
					$setPaginate.= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
			}
		}
		elseif($setLastpage > 5 + ($adjacents * 2))
		{
			if($page < 1 + ($adjacents * 2))
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$setPaginate.= "<li><a class='current_page'>$counter</a></li>";
					else
						$setPaginate.= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
				}
				$setPaginate.= "<li class='dot'>...</li>";
				$setPaginate.= "<li><a href='{$page_url}page=$lpm1'>$lpm1</a></li>";
				$setPaginate.= "<li><a href='{$page_url}page=$setLastpage'>$setLastpage</a></li>";
			}
			elseif($setLastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$setPaginate.= "<li><a href='{$page_url}page=1'>1</a></li>";
				$setPaginate.= "<li><a href='{$page_url}page=2'>2</a></li>";
				$setPaginate.= "<li class='dot'>...</li>";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$setPaginate.= "<li><a class='current_page'>$counter</a></li>";
					else
						$setPaginate.= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
				}
				$setPaginate.= "<li class='dot'>..</li>";
				$setPaginate.= "<li><a href='{$page_url}page=$lpm1'>$lpm1</a></li>";
				$setPaginate.= "<li><a href='{$page_url}page=$setLastpage'>$setLastpage</a></li>";
			}
			else
			{
				$setPaginate.= "<li><a href='{$page_url}page=1'>1</a></li>";
				$setPaginate.= "<li><a href='{$page_url}page=2'>2</a></li>";
				$setPaginate.= "<li class='dot'>..</li>";
				for ($counter = $setLastpage - (2 + ($adjacents * 2)); $counter <= $setLastpage; $counter++)
				{
					if ($counter == $page)
						$setPaginate.= "<li><a class='current_page'>$counter</a></li>";
					else
						$setPaginate.= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
				}
			}
		}

		if ($page < $counter - 1){
			$setPaginate.= "<li><a href='{$page_url}page=$next'>Next</a></li>";
      $setPaginate.= "<li><a href='{$page_url}page=$setLastpage'>Last</a></li>";
		}else{
			$setPaginate.= "<li><a class='current_page'>Next</a></li>";
          $setPaginate.= "<li><a class='current_page'>Last</a></li>";
        }
			$setPaginate.= "</ul>\n";
	}
    return $setPaginate;
}

?>
